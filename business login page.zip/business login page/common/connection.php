<?php
$connect=mysqli_connect("localhost","root","","myproject")or failed("connection-failed");
?>